from django.shortcuts import render, HttpResponse
from .models import Items
import requests
from django.core.mail import send_mail


# Create your views here.

def index(request):
    return render(request, 'index.html')

def fetch(request):

    try:  
        item  = Items.objects.get(name='Test3') 
        
    except:   

        # Here task will created in clickup

        values = """
        {
            "name": "Fix the bug",
            "description": "Site has crashed or slow down, fix it as soon as possible",
            "assignees": [
            14563
            ],
            "tags": [
            "Demo Site"
            ],
            "status": "Open",
            "priority": 1,
            "due_date": 1508369194377,
            "due_date_time": false,
            "time_estimate": 8640000,
            "start_date": 1567780450202,
            "start_date_time": false,
            "notify_all": true,
            "parent": null,
            "links_to": null,

        }
        """

        headers = {
        'Authorization': 'pk_55258512_PVIQME6J6P4HUIKJYDMPKOEZO2X4YWWG',
        'Content-Type': 'application/json'
        }

        request = requests.post('https://api.clickup.com/api/v2/list/175330462/task', data=values, headers=headers)

        
        print(request)

        # Get the ticket URL

        ticket_url = request.url

        # Send mail to developer

        send_mail(
            "Fix the bug",
            "Hello Developer, the site has crashed or slow down due to some reason. This is the ticket url : {ticket_url}. Please fix it as soon as possible. Thank You",
            'chahat85@gmail.com',
            ['shrutikaj8584@gmail.com'],
            fail_silently=False,
        )

    return HttpResponse("Please wait, we are fixing the issue!")